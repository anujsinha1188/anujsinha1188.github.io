package com.infy.service;

public class CustomerServiceImpl implements CustomerService {

	public String createCustomer() {
		return "Customer is successfully created";
	}

}
