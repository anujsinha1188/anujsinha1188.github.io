package com.infy.service;

public interface CustomerService {

	public String fetchCustomer();

}