package com.infy.service;

public interface CustomerService {
	public String fetchCustomer(int count);
	public String createCustomer();
}
